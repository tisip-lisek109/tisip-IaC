az appservice plan show --name "timlab-dev-asp" --resource-group "timlab-dev-rg"
az webapp config appsettings list --name "timlab-dev-webapp" --resource-group "timlab-dev-rg"